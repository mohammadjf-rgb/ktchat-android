# SOURCE STATUS

- Product: KT-Chat Android
- Version: 1.0.14
- Base: KT-Chat Windows v1.0.14
- Android package: com.karmaniatajhiz.ktchat
- Default server: http://192.168.10.42:8789
- QNAP/database update: NOT REQUIRED
- Android UI: WebView-hosted adapted v1.0.14 UI + native Java bridge
- No third-party runtime dependencies.
