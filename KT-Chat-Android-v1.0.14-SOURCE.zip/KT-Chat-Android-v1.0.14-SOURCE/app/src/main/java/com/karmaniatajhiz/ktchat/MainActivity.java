package com.karmaniatajhiz.ktchat;

import android.Manifest;
import android.app.Activity;
import android.app.DownloadManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {
    private static final String DEFAULT_SERVER = "http://192.168.10.42:8789";
    private static final String PREFS = "ktchat_android";
    private static final String CHANNEL = "ktchat_messages";
    private static final int FILE_REQUEST = 501;
    private static final int NOTIFY_PERMISSION = 502;

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private SharedPreferences prefs;
    private final Map<Long, Boolean> openDownloads = new HashMap<>();

    private final BroadcastReceiver downloadReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!DownloadManager.ACTION_DOWNLOAD_COMPLETE.equals(intent.getAction())) return;
            long id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);
            Boolean shouldOpen = openDownloads.remove(id);
            if (!Boolean.TRUE.equals(shouldOpen)) return;
            try {
                DownloadManager dm = (DownloadManager)getSystemService(DOWNLOAD_SERVICE);
                Uri uri = dm.getUriForDownloadedFile(id);
                if (uri == null) return;
                String mime = dm.getMimeTypeForDownloadedFile(id);
                Intent view = new Intent(Intent.ACTION_VIEW);
                view.setDataAndType(uri, (mime == null || mime.isEmpty()) ? "*/*" : mime);
                view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(view);
            } catch (Exception ex) {
                Toast.makeText(MainActivity.this, "فایل دانلود شد؛ از پوشه Downloads باز کنید.", Toast.LENGTH_LONG).show();
            }
        }
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        createNotificationChannel();
        requestNeededPermissions();
        registerDownloadReceiver();

        web = new WebView(this);
        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            ws.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }
        ws.setUserAgentString(ws.getUserAgentString() + " KT-Chat-Android/1.0.14");

        web.addJavascriptInterface(new AndroidBridge(), "Android");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    Intent i = params.createIntent();
                    i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    startActivityForResult(i, FILE_REQUEST);
                    return true;
                } catch (Exception ex) {
                    fileCallback = null;
                    Toast.makeText(MainActivity.this, "انتخاب فایل در دسترس نیست", Toast.LENGTH_LONG).show();
                    return false;
                }
            }
        });
        setContentView(web);
        loadApp();
    }

    private void registerDownloadReceiver() {
        IntentFilter f = new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(downloadReceiver, f, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(downloadReceiver, f);
    }

    private void requestNeededPermissions() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFY_PERMISSION);
        }
        if (Build.VERSION.SDK_INT <= 28 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 503);
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "KT-Chat messages", NotificationManager.IMPORTANCE_HIGH);
            c.setDescription("اعلان پیام‌های جدید KT-Chat");
            c.enableVibration(true);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }

    private String server() {
        String s = prefs.getString("server", DEFAULT_SERVER);
        if (s == null || s.trim().isEmpty()) return DEFAULT_SERVER;
        s = s.trim();
        while (s.endsWith("/")) s = s.substring(0, s.length()-1);
        return s;
    }

    private void loadApp() {
        try {
            InputStream in = getAssets().open("index.html");
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            byte[] buf = new byte[16384]; int n;
            while ((n = in.read(buf)) >= 0) b.write(buf, 0, n);
            in.close();
            String html = b.toString("UTF-8");
            web.loadDataWithBaseURL(server() + "/", html, "text/html", "UTF-8", null);
        } catch (Exception ex) {
            Toast.makeText(this, "خطا در بارگذاری KT-Chat: " + ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_REQUEST || fileCallback == null) return;
        Uri[] result = null;
        if (resultCode == RESULT_OK && data != null) {
            ClipData clip = data.getClipData();
            if (clip != null) {
                result = new Uri[clip.getItemCount()];
                for (int i=0;i<clip.getItemCount();i++) result[i] = clip.getItemAt(i).getUri();
            } else if (data.getData() != null) {
                result = new Uri[]{data.getData()};
            }
        }
        fileCallback.onReceiveValue(result);
        fileCallback = null;
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        try { unregisterReceiver(downloadReceiver); } catch (Exception ignored) {}
        if (web != null) { web.destroy(); web = null; }
        super.onDestroy();
    }

    public final class AndroidBridge {
        @JavascriptInterface public String getServer() { return server(); }
        @JavascriptInterface public String machineName() { return Build.MANUFACTURER + " " + Build.MODEL; }

        @JavascriptInterface public void setServer(String url) {
            if (url == null) return;
            String s = url.trim();
            if (!(s.startsWith("http://") || s.startsWith("https://"))) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "آدرس Server باید با http:// یا https:// شروع شود", Toast.LENGTH_LONG).show());
                return;
            }
            while (s.endsWith("/")) s = s.substring(0, s.length()-1);
            prefs.edit().putString("server", s).apply();
            runOnUiThread(MainActivity.this::loadApp);
        }

        @JavascriptInterface public String getCredentials() {
            try {
                JSONObject o = new JSONObject();
                o.put("saved", prefs.getBoolean("cred_saved", false));
                o.put("username", prefs.getString("username", ""));
                o.put("password", prefs.getString("password", ""));
                return o.toString();
            } catch (Exception e) { return "{\"saved\":false}"; }
        }

        @JavascriptInterface public void saveCredentials(String user, String pass) {
            prefs.edit().putBoolean("cred_saved", true).putString("username", user == null ? "" : user).putString("password", pass == null ? "" : pass).apply();
        }

        @JavascriptInterface public void clearCredentials() {
            prefs.edit().remove("cred_saved").remove("username").remove("password").apply();
        }

        @JavascriptInterface public void playSound(String kind) {
            runOnUiThread(() -> {
                try {
                    int res = "group".equals(kind) ? R.raw.chat_public : R.raw.chat_private;
                    MediaPlayer mp = MediaPlayer.create(MainActivity.this, res);
                    if (mp != null) {
                        mp.setOnCompletionListener(MediaPlayer::release);
                        mp.start();
                    }
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface public void attention() {
            try {
                Vibrator v = (Vibrator)getSystemService(VIBRATOR_SERVICE);
                if (v == null) return;
                if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(120, VibrationEffect.DEFAULT_AMPLITUDE));
                else v.vibrate(120);
            } catch (Exception ignored) {}
        }

        @JavascriptInterface public void notifyMessage(String title, String message, String target) {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(MainActivity.this, MainActivity.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    PendingIntent pi = PendingIntent.getActivity(MainActivity.this, 100, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                    android.app.Notification.Builder b = Build.VERSION.SDK_INT >= 26
                        ? new android.app.Notification.Builder(MainActivity.this, CHANNEL)
                        : new android.app.Notification.Builder(MainActivity.this);
                    b.setSmallIcon(R.drawable.app_icon)
                     .setContentTitle(title == null ? "KT-Chat" : title)
                     .setContentText(message == null ? "پیام جدید" : message)
                     .setStyle(new android.app.Notification.BigTextStyle().bigText(message == null ? "پیام جدید" : message))
                     .setAutoCancel(true).setContentIntent(pi);
                    int id = Math.abs((target == null ? message : target).hashCode());
                    ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(id, b.build());
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface public void downloadFile(String fileId, String fileName, String token, boolean openAfter) {
            runOnUiThread(() -> {
                try {
                    String id = URLEncoder.encode(fileId == null ? "" : fileId, "UTF-8");
                    Uri uri = Uri.parse(server() + "/api/file/download?id=" + id);
                    DownloadManager.Request r = new DownloadManager.Request(uri);
                    if (token != null && !token.isEmpty()) r.addRequestHeader("Authorization", "Bearer " + token);
                    String safe = safeFileName(fileName);
                    r.setTitle(safe);
                    r.setDescription("KT-Chat");
                    r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, safe);
                    DownloadManager dm = (DownloadManager)getSystemService(DOWNLOAD_SERVICE);
                    long downloadId = dm.enqueue(r);
                    openDownloads.put(downloadId, openAfter);
                    Toast.makeText(MainActivity.this, openAfter ? "در حال دریافت فایل..." : "دانلود شروع شد", Toast.LENGTH_SHORT).show();
                } catch (Exception ex) {
                    Toast.makeText(MainActivity.this, "دانلود فایل ناموفق بود: " + ex.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface public void exitApp() { runOnUiThread(MainActivity.this::finishAndRemoveTask); }
    }

    private static String safeFileName(String name) {
        String n = (name == null || name.trim().isEmpty()) ? "KTChat-file" : name.trim();
        n = n.replace('/', '_').replace('\\', '_').replace(':', '_').replace('*', '_').replace('?', '_').replace('"', '_').replace('<', '_').replace('>', '_').replace('|', '_');
        if (n.length() > 180) n = n.substring(0, 180);
        return n;
    }
}
