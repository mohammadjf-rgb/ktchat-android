# KT-Chat Android v1.0.14

نسخه Android بر پایه آخرین KT-Chat Windows v1.0.14 ساخته شده است.

## اتصال پیش‌فرض
`http://192.168.10.42:8789`

برای Login همان کاربران KTIMA استفاده می‌شوند و KT-Chat Server همچنان Authentication را از KTIMA روی QNAP می‌گیرد.

## قابلیت‌ها
- گفتگوی عمومی و خصوصی
- نمایش کاربران Online/Offline
- Reply / Edit / Delete
- Read receipt
- جداکننده «پیام‌های جدید»
- ساعت Local دستگاه Android
- Search / Archive
- انتخاب و Upload چند فایل از Android file picker
- نام فایل فارسی/Unicode
- Download و Open فایل با Android DownloadManager
- اعلان و صدای پیام هنگام فعال بودن WebView/Process
- تنظیم رنگ گفتگو و فونت/اندازه
- ذخیره Server و Credentials در فضای خصوصی برنامه

## نکته اعلان Background
این نسخه بدون Firebase/Push server ساخته شده است. Android ممکن است اجرای JavaScript WebView را در Background محدود کند، بنابراین اعلان Real-time وقتی برنامه کاملاً در Background/Doze باشد تضمین نمی‌شود. وقتی برنامه فعال است یا Process زنده است Sync سه‌ثانیه‌ای نسخه Windows حفظ می‌شود.

## Build
Android Studio: پوشه پروژه را Open و `Build > Build APK(s)` اجرا کنید.

یا در GitHub Actions، Workflow موجود `Build Android APK` را اجرا کنید.

## Server / Database
برای این Android Client هیچ تغییر Database یا QNAP KT-Chat Server لازم نیست. UI با base URL خود Server بارگذاری می‌شود تا درخواست‌های `/api/*` same-origin باشند.
